﻿using Microsoft.Data.SqlClient;
using System.Data;
using Dapper;
namespace WebApplication3
{
    public abstract class DapperBaseRepository<T> : IRepository<T> where T : EntityBase
    {
        protected readonly IConfiguration _configuration;
        protected readonly SqlConnection _connection;

        protected DapperBaseRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            _connection = new SqlConnection(_configuration.GetConnectionString("DefaultConnection"));
        }

        public abstract Task<IEnumerable<T>> GetAllAsync();
        public abstract Task<T?> GetByIdAsync(int id);
        public abstract Task<T> AddAsync(T entity);
        public abstract Task UpdateAsync(T entity);
        public abstract Task DeleteAsync(int id);
    }

}
