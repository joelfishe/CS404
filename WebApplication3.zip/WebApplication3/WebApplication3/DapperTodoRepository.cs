﻿using Dapper;
namespace WebApplication3
{
    public class DapperTodoRepository : DapperBaseRepository<Todo>, IRepository<Todo>
    {
        public DapperTodoRepository(IConfiguration configuration) : base(configuration) { }

        public override async Task<IEnumerable<Todo>> GetAllAsync()
        {
            var sql = _configuration["SqlQueries:GetAllTodos"];
            return await _connection.QueryAsync<Todo>(sql);
        }

        public override async Task<Todo?> GetByIdAsync(int id)
        {
            var sql = _configuration["SqlQueries:GetTodoById"];
            return await _connection.QuerySingleOrDefaultAsync<Todo>(sql, new { Id = id });
        }

        public override async Task<Todo> AddAsync(Todo entity)
        {
            var sql = _configuration["SqlQueries:AddTodo"];
            var id = await _connection.ExecuteScalarAsync<int>(sql, entity);
            entity.Id = id;
            return entity;
        }

        public override async Task UpdateAsync(Todo entity)
        {
            var sql = _configuration["SqlQueries:UpdateTodo"];
            await _connection.ExecuteAsync(sql, entity);
        }

        public override async Task DeleteAsync(int id)
        {
            var sql = _configuration["SqlQueries:DeleteTodo"];
            await _connection.ExecuteAsync(sql, new { Id = id });
        }
    }

}
