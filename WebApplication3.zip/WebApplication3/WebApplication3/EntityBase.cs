﻿using Dapper;
namespace WebApplication3
{
    public abstract class EntityBase
    {
        public int Id { get; set; }
    }

}
