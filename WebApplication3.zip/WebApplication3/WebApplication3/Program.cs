using FluentValidation;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using WebApplication3;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<TodoDb>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

// Comment out or remove the Dapper repository
// builder.Services.AddScoped<IRepository<Todo>, DapperTodoRepository>();

builder.Services.AddScoped<IRepository<Todo>, TodoRepository>();
builder.Services.AddScoped<TodoService>();
builder.Services.AddScoped<IValidator<Todo>, TodoValidator>();
builder.Services.AddSwaggerGen();



var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
};


app.MapGet("/todoitems", async (TodoService service) =>
    await service.GetAllTodosAsync());

app.MapGet("/todoitems/complete", async (TodoService service) =>
    (await service.GetAllTodosAsync()).Where(t => t.IsComplete));

app.MapGet("/todoitems/{id}", async (int id, TodoService service) =>
    await service.GetTodoByIdAsync(id) is Todo todo
        ? Results.Ok(todo)
        : Results.NotFound());

app.MapPost("/todoitems", async (Todo todo, TodoService service) =>
{
    try
    {
        var newTodo = await service.AddTodoAsync(todo);
        return Results.Created($"/todoitems/{newTodo.Id}", newTodo);
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(ex.Message);
    }
});

app.MapPut("/todoitems/{id}", async (int id, Todo inputTodo, TodoService service) =>
{
    var todo = await service.GetTodoByIdAsync(id);
    if (todo is null) return Results.NotFound();

    todo.Name = inputTodo.Name;
    todo.IsComplete = inputTodo.IsComplete;
    todo.DueDate = inputTodo.DueDate;

    await service.UpdateTodoAsync(todo);
    return Results.NoContent();
});

app.MapDelete("/todoitems/{id}", async (int id, TodoService service) =>
{
    var todo = await service.GetTodoByIdAsync(id);
    if (todo is null) return Results.NotFound();

    await service.DeleteTodoAsync(id);
    return Results.NoContent();
});

app.Run();
