﻿namespace WebApplication3
{
    public abstract class RepositoryBase
    {
        protected readonly TodoDb _context;
    }
}