﻿namespace WebApplication3
{
    public class Todo : EntityBase
    {
        public string? Name { get; set; }
        public bool IsComplete { get; set; }
        public DateTime DueDate { get; set; }
    }

}
