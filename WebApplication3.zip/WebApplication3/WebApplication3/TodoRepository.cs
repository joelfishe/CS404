﻿namespace WebApplication3
{
    public class TodoRepository : BaseRepository<Todo>, IRepository<Todo>
    {
        public TodoRepository(TodoDb context) : base(context) { }
    }

}
