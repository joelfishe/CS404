﻿using FluentValidation;

namespace WebApplication3
{
    public class TodoService
    {
        private readonly IRepository<Todo> _repository;
        private readonly IValidator<Todo> _validator;

        public TodoService(IRepository<Todo> repository, IValidator<Todo> validator)
        {
            _repository = repository;
            _validator = validator;
        }

        public async Task<Todo> AddTodoAsync(Todo todo)
        {
            var validationResult = await _validator.ValidateAsync(todo);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }
            return await _repository.AddAsync(todo);
        }
        public async Task<IEnumerable<Todo>> GetAllTodosAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<Todo?> GetTodoByIdAsync(int id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public async Task UpdateTodoAsync(Todo todo)
        {
            await _repository.UpdateAsync(todo);
        }

        public async Task DeleteTodoAsync(int id)
        {
            await _repository.DeleteAsync(id);
        }
    }

}
