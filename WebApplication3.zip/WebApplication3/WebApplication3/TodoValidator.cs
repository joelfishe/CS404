﻿using FluentValidation;

namespace WebApplication3
{
    public class TodoValidator : AbstractValidator<Todo>
    {
        public TodoValidator()
        {
            RuleFor(x => x.Name).NotEmpty().MaximumLength(100);
            RuleFor(x => x.DueDate).GreaterThan(DateTime.Now);
        }
    }

}
